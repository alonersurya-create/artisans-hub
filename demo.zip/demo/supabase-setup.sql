-- ================================================================
-- THE ARTISANS HUB — Supabase Database Setup
-- Run this entire file in your Supabase project's SQL Editor
-- ================================================================

-- 1. CATEGORIES TABLE
CREATE TABLE IF NOT EXISTS tah_categories (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  emoji TEXT DEFAULT '🏷️',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. PRODUCTS TABLE
CREATE TABLE IF NOT EXISTS tah_products (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  category_id BIGINT REFERENCES tah_categories(id) ON DELETE SET NULL,
  price NUMERIC(10,2) NOT NULL DEFAULT 0,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. ORDERS TABLE
CREATE TABLE IF NOT EXISTS tah_orders (
  id BIGSERIAL PRIMARY KEY,
  order_no TEXT NOT NULL UNIQUE,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  address TEXT,
  note TEXT,
  items JSONB,
  total NUMERIC(10,2),
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ================================================================
-- ROW LEVEL SECURITY
-- ================================================================
ALTER TABLE tah_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE tah_products   ENABLE ROW LEVEL SECURITY;
ALTER TABLE tah_orders     ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public read categories"      ON tah_categories FOR SELECT USING (true);
CREATE POLICY "Public read products"        ON tah_products   FOR SELECT USING (true);
CREATE POLICY "Anon full access categories" ON tah_categories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Anon full access products"   ON tah_products   FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Anon insert orders"          ON tah_orders     FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon read orders"            ON tah_orders     FOR SELECT USING (true);

-- ================================================================
-- CATEGORIES (11 total)
-- ================================================================
INSERT INTO tah_categories (name, emoji) VALUES
  ('Handpainted Gifts',    '🎨'),
  ('Candles & Aroma',      '🕯️'),
  ('Personalized Gifts',   '💝'),
  ('Jute & Eco Crafts',    '🌿'),
  ('Resin Art',            '💎'),
  ('Customized Gifts',     '✨'),
  ('Printed Mugs',         '☕'),
  ('Frames & Wall Art',    '🖼️'),
  ('Trophies & Awards',    '🏆'),
  ('Mementos & Keepsakes', '🎖️'),
  ('Stationery',           '✏️')
ON CONFLICT DO NOTHING;

-- ================================================================
-- PRODUCTS (35 total across all categories)
-- ================================================================
-- NOTE: category_id numbers depend on insertion order above.
-- If re-running, adjust ids to match your actual category ids.

INSERT INTO tah_products (name, code, category_id, price, description) VALUES
  -- Handpainted Gifts
  ('Hand-Painted Mandala Tray',      'TAH-001', 1, 599,  'Beautiful hand-painted mandala art on wooden serving tray. Perfect for home decor and gifting.'),
  ('Watercolour Floral Pot',          'TAH-002', 1, 449,  'Hand-painted terracotta pot with vibrant watercolour floral art. Ideal for plant lovers.'),
  -- Candles & Aroma
  ('Soy Wax Lavender Candle',         'TAH-003', 2, 349,  'Handpoured soy wax candle with dried lavender. Burns for 35-40 hours with a calming fragrance.'),
  ('Rose Petal Aroma Diffuser Set',   'TAH-004', 2, 599,  'Reed diffuser set with rose petal & jasmine blend. Long-lasting 60-day fragrance for any room.'),
  -- Personalized Gifts
  ('Personalized Name Keychain',      'TAH-005', 3, 199,  'Custom wooden keychain with your name. A unique and thoughtful gift.'),
  ('Engraved Couple Name Plaque',     'TAH-006', 3, 749,  'Wooden plaque laser-engraved with couple names and date. Perfect wedding or anniversary gift.'),
  -- Jute & Eco Crafts
  ('Jute Tote Gift Bag',              'TAH-007', 4, 249,  'Eco-friendly hand-stitched jute tote. Perfect for gifting or daily use.'),
  ('Floral Macrame Wall Hanging',     'TAH-008', 4, 899,  'Hand-knotted macrame wall art with dried flowers. Adds boho charm to any room.'),
  -- Resin Art
  ('Resin Ocean Coaster Set',         'TAH-009', 5, 799,  'Set of 4 handcrafted resin coasters with ocean wave effect. Each piece is unique.'),
  ('Resin Geode Serving Tray',        'TAH-010', 5, 1299, 'Stunning geode-art resin tray with gold leaf accents. A showstopper gift for any occasion.'),
  -- Customized Gifts
  ('Custom Caricature Portrait',      'TAH-011', 6, 899,  'Handdrawn digital caricature portrait of your loved one. Delivered as print-ready file + print.'),
  ('Personalized Gift Hamper Box',    'TAH-012', 6, 1499, 'Fully customized gift hamper with your choice of items, ribbon, and personalized card.'),
  ('Name-Engraved Wooden Box',        'TAH-013', 6, 649,  'Elegant wooden gift box laser-engraved with any name or message. Great for all occasions.'),
  ('Custom Photo Album',              'TAH-014', 6, 849,  'Handcrafted personalized photo album with jute cover and hand-stitched binding.'),
  -- Printed Mugs
  ('Magic Colour-Changing Mug',       'TAH-015', 7, 349,  'Reveal your photo/message when hot liquid is poured. Great birthday or Valentine gift.'),
  ('Personalised Photo Mug',          'TAH-016', 7, 299,  'High-quality ceramic mug printed with your photo and custom text. Dishwasher safe.'),
  ('Couple Mug Set (2 pcs)',          'TAH-017', 7, 599,  'Set of 2 matching mugs for couples with custom names. Comes in a gift box.'),
  ('Motivational Quote Mug',          'TAH-018', 7, 279,  'Boldly printed motivational quotes on premium ceramic. Choose from 20+ designs.'),
  -- Frames & Wall Art
  ('LED Photo Frame',                 'TAH-019', 8, 699,  'Elegant LED-backlit photo frame for a warm glowing display. Perfect for bedrooms.'),
  ('Shadow Box Memory Frame',         'TAH-020', 8, 899,  'Deep shadow box frame to display photos, tickets, flowers and keepsakes together.'),
  ('Collage Wall Frame Set (6 pcs)',  'TAH-021', 8, 1099, 'Set of 6 matching rustic frames in varying sizes for a gallery wall. Ready to hang.'),
  ('Personalised Quote Canvas Print', 'TAH-022', 8, 749,  'Your chosen quote printed on stretched canvas with a hand-painted border.'),
  -- Trophies & Awards
  ('Crystal Glass Trophy',            'TAH-023', 9, 1199, 'Premium optical crystal trophy with laser-engraved name and achievement. Ideal for corporate events.'),
  ('Wooden Shield Trophy',            'TAH-024', 9, 799,  'Handcrafted wooden shield trophy with brass plate engraving. Timeless recognition award.'),
  ('Acrylic Star Trophy',             'TAH-025', 9, 649,  'Vibrant acrylic star trophy available in 5 colours. Personalised with name and message.'),
  ('Sports Medal with Ribbon',        'TAH-026', 9, 299,  'Custom zinc alloy medal with coloured enamel and satin ribbon. Bulk orders available.'),
  -- Mementos & Keepsakes
  ('Personalised Family Tree Art',    'TAH-027', 10, 999, 'Beautifully illustrated family tree with member names laser-engraved on wood.'),
  ('Memory Jar with Notes',           'TAH-028', 10, 449, 'Mason jar filled with 52 handwritten memory note prompts. A gift that lasts all year.'),
  ('Handprint / Footprint Frame Kit', 'TAH-029', 10, 549, 'DIY kit to capture baby or child handprints/footprints in clay and display in a frame.'),
  ('Couple Fingerprint Keychain',     'TAH-030', 10, 349, 'Two keychains with fingerprints pressed in sterling silver clay. Unique couple gift.'),
  -- Stationery
  ('Handmade Paper Notebook',         'TAH-031', 11, 299, 'Eco-friendly handmade paper journal with jute cover. 120 acid-free pages, unruled.'),
  ('Wax Seal Stamp Kit',              'TAH-032', 11, 499, 'Vintage wax seal stamp set with 3 designs, 5 wax sticks and a melting spoon.'),
  ('Custom Desk Name Plate',          'TAH-033', 11, 399, 'Personalised wooden desk nameplate — perfect for offices, teachers and work-from-home setups.'),
  ('Premium Pen Gift Set',            'TAH-034', 11, 549, 'Set of 3 premium metal pens in a velvet box. Engravable with name or message.'),
  ('Personalised Sticker Sheet Pack', 'TAH-035', 11, 149, 'Custom sticker sheets with name, initials or artwork. 50 stickers per pack, waterproof.')
ON CONFLICT DO NOTHING;
